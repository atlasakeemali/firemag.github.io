/* ============================================================
   FIRE!!! — Call for Proposals (Phase 1)
   Composes the bound FIRE!!! Design System components
   (window.FIREDesignSystem_8ea621) into the CFP landing,
   submission flow, and confirmation. Big Shoulders / Limelight /
   Newsreader; committed-escalating-to-drenched color strategy.
   ============================================================ */

const DS = window.FIREDesignSystem_8ea621;
const { Button, Sawtooth, Ring, Badge, Kicker, Field, PullQuote } = DS;
const { CultureMark, PoliticsMark, EconomicsMark } = window.FireMarks;
const { useTweaks, TweaksPanel, TweakSection, TweakSlider, TweakToggle, TweakRadio } = window;

const wrap = { width: "min(74rem, 100% - 3rem)", marginInline: "auto" };
const disp = { fontFamily: "var(--font-display)" };
const kickerStyle = { ...disp, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.14em" };

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "redIntensity": "committed",
  "heroScale": 1,
  "showMarks": true,
  "grain": true
}/*EDITMODE-END*/;

/* ----- color escalation: which surfaces go red ----- */
function surfaces(intensity) {
  const deep = { bg: "var(--flame-700)", theme: "ink" };       // deep-red panel, bone text
  const poster = { bg: "var(--flame-600)", theme: "flame" };   // poster red, ink display
  const bone = { bg: "var(--bone-50)", theme: null };
  if (intensity === "restrained")
    return { triad: bone, who: bone, submit: bone };
  if (intensity === "drenched")
    return { triad: poster, who: deep, submit: deep };
  return { triad: bone, who: deep, submit: deep }; // committed (default)
}

/* ============================================================ NAV */
function Nav({ view, onSubmit, onHome }) {
  const links = [["The Call", "the-call"], ["Sections", "sections"], ["No AI", "no-ai"], ["Who", "who"], ["The Work", "the-work"]];
  const [open, setOpen] = React.useState(false);
  return (
    <nav aria-label="Primary" style={{ background: "var(--bone-50)", borderBottom: "6px solid var(--ink-900)", position: "sticky", top: 0, zIndex: 30 }}>
      <div style={{ ...wrap, display: "flex", alignItems: "center", gap: "1.5rem", padding: "0.85rem 0" }}>
        <a href="#top" onClick={(e) => { e.preventDefault(); onHome(); }}
          style={{ ...disp, fontWeight: 900, fontSize: "1.7rem", color: "var(--ink-900)", textDecoration: "none", letterSpacing: "0.01em", marginRight: "auto" }}>FIRE!!!</a>
        <div className="nav-links" style={{ display: "flex", alignItems: "center", gap: "1.4rem" }}>
          {links.map(([label, id]) => (
            <a key={id} href={"#" + id}
              onClick={(e) => { if (view !== "landing") { e.preventDefault(); onHome(); setTimeout(() => { const el = document.getElementById(id); if (el) el.scrollIntoView(); }, 60); } }}
              style={{ ...kickerStyle, fontSize: "0.78rem", color: "var(--ink-900)", textDecoration: "none", whiteSpace: "nowrap", paddingBottom: "2px", borderBottom: "3px solid transparent" }}
              onMouseEnter={(e) => (e.currentTarget.style.borderBottomColor = "var(--flame-600)")}
              onMouseLeave={(e) => (e.currentTarget.style.borderBottomColor = "transparent")}>{label}</a>
          ))}
        </div>
        <Button size="sm" onClick={onSubmit}>Submit a Proposal</Button>
      </div>
      <style>{`@media (max-width: 760px){ .nav-links{ display:none !important; } }`}</style>
    </nav>
  );
}

/* ============================================================ HERO */
function Hero({ scale, onRead, onSubmit }) {
  return (
    <header id="top" data-theme="flame" style={{ background: "var(--flame-500)", color: "var(--ink-900)", padding: "clamp(3rem,7vw,5.5rem) 0 0", overflow: "hidden" }}>
      <div style={wrap}>
        <p className="rise" style={{ ...kickerStyle, fontWeight: 700, fontSize: "clamp(0.95rem,1.9vw,1.5rem)", color: "var(--ink-900)", margin: 0, display: "flex", alignItems: "center", justifyContent: "space-between", gap: "0.9rem", whiteSpace: "nowrap", letterSpacing: "0.1em" }}>
          <span>Culture</span> <Ring size={15} color="var(--ink-900)" /> <span>Politics</span> <Ring size={15} color="var(--ink-900)" /> <span>Economics</span>
        </p>
        <h1 className="rise" style={{ ...disp, fontWeight: 900, fontSize: `clamp(4.5rem, ${19 * scale}vw, ${16 * scale}rem)`, lineHeight: 0.84, letterSpacing: "0.005em", color: "var(--ink-900)", margin: "0.4rem 0 0", textTransform: "uppercase", "--rise-delay": "40ms" }}>FIRE!!!</h1>
        <p className="rise" style={{ fontFamily: "var(--font-body)", fontStyle: "italic", fontSize: "clamp(1.25rem,2.7vw,1.85rem)", color: "var(--ink-900)", margin: "0.6rem 0 0", maxWidth: "none", "--rise-delay": "90ms" }}>Devoted to Younger African American Artists</p>

        <div className="rise" style={{ marginTop: "2.5rem", borderTop: "6px solid var(--ink-900)", paddingTop: "1rem", display: "flex", alignItems: "baseline", gap: "0.65rem 1.4rem", flexWrap: "wrap", "--rise-delay": "140ms" }}>
          <span style={{ ...kickerStyle, fontSize: "0.82rem", lineHeight: 1.1 }}>Call for Proposals</span>
          <span style={{ ...disp, fontWeight: 800, fontSize: "clamp(1.5rem,3.6vw,2.6rem)", textTransform: "uppercase", lineHeight: 1 }}>June 15 — August 14, 2026</span>
        </div>
        <div className="rise" style={{ marginTop: "2.25rem", paddingBottom: "3rem", display: "flex", gap: "1rem", flexWrap: "wrap", "--rise-delay": "190ms" }}>
          <Button size="lg" onClick={onRead}>Read the Call ↓</Button>
          <Button variant="secondary" size="lg" onClick={onSubmit}>Submit a Proposal</Button>
        </div>
      </div>
    </header>
  );
}

/* ============================================================ THE CALL + 1926 PLATE */
function TheCall() {
  return (
    <section id="the-call" style={{ background: "var(--bone-50)", padding: "clamp(4rem,8vw,7rem) 0" }}>
      <div style={wrap}>
        <div style={{ display: "grid", gridTemplateColumns: "minmax(0,1.55fr) minmax(0,1fr)", gap: "clamp(2rem,5vw,4.5rem)", alignItems: "start" }} className="call-grid">
          <div>
            <div className="rise"><Kicker kicker="The Call" size="feature" headline="A hundred years later, the fire still burns." /></div>
            <p className="rise" style={{ fontFamily: "var(--font-body)", fontSize: "clamp(1.3rem,2.3vw,1.6rem)", fontWeight: 500, lineHeight: 1.5, color: "var(--ink-900)", maxWidth: "62ch", marginTop: "2rem", "--rise-delay": "60ms" }}>
              In 1926, Wallace Thurman, Langston Hughes, Zora Neale Hurston, and Aaron Douglas lit a match called <em>FIRE!!</em>, a journal by younger Black artists who refused permission.
            </p>
            <p className="rise" style={{ ...disp, fontWeight: 800, fontSize: "clamp(1.8rem,4vw,2.85rem)", lineHeight: 1, textTransform: "uppercase", color: "var(--flame-600)", margin: "1.4rem 0 0", "--rise-delay": "90ms" }}>
              It ran one issue. It changed everything.
            </p>
            <p className="rise" style={{ fontFamily: "var(--font-body)", fontSize: "var(--text-base)", lineHeight: 1.62, color: "var(--ink-900)", maxWidth: "62ch", marginTop: "1.5rem", "--rise-delay": "120ms" }}>
              Now we strike the match again. FIRE!!! returns to publish twenty-one new pieces, paid, in the spirit of the original. We are giving emerging African American writers, poets, photographers, and artists a seat at the table across three sections: Culture, Politics, and Economics.
            </p>
            <div className="rise" style={{ marginTop: "2.5rem", display: "flex", gap: "1.25rem", alignItems: "center", flexWrap: "wrap", "--rise-delay": "150ms" }} aria-label="1926 to 2026">
              <span style={{ ...disp, fontWeight: 900, fontSize: "clamp(2rem,5vw,3.25rem)", color: "var(--ink-900)" }}>1926</span>
              <span aria-hidden="true" style={{ fontFamily: "var(--font-body)", fontStyle: "italic", fontWeight: 400, fontSize: "clamp(1.6rem,4vw,2.5rem)", color: "var(--flame-600)" }}>to</span>
              <span style={{ ...disp, fontWeight: 900, fontSize: "clamp(2rem,5vw,3.25rem)", color: "var(--ink-900)" }}>2026</span>
            </div>
          </div>

          {/* Genuine 1926 cover — public domain — framed as an archival plate */}
          <figure className="rise" style={{ margin: 0, "--rise-delay": "100ms" }}>
            <div style={{ border: "6px solid var(--ink-900)", background: "var(--ink-900)" }}>
              <img src="assets/fire-1926-cover.png" alt="The original FIRE!! cover, 1926, designed by Aaron Douglas: a reclining sphinx and a profile silhouette in warm black against vermillion red."
                style={{ display: "block", width: "100%", height: "auto" }} />
            </div>
            <figcaption style={{ ...kickerStyle, fontWeight: 600, fontSize: "0.72rem", color: "var(--ink-700)", marginTop: "0.85rem", lineHeight: 1.5 }}>
              <span style={{ color: "var(--flame-600)" }}>№ 1</span> · FIRE!! · November 1926<br />Cover by Aaron Douglas · public domain
            </figcaption>
          </figure>
        </div>

        <div className="rise" style={{ "--rise-delay": "120ms" }}>
          <PullQuote cite="Foreword · FIRE!! · 1926">FIRE … flaming, burning, searing, and penetrating far beneath the superficial items of the flesh.</PullQuote>
        </div>
      </div>
      <style>{`@media (max-width: 820px){ .call-grid{ grid-template-columns: 1fr !important; } }`}</style>
    </section>
  );
}

/* ============================================================ THE TRIAD (Culture / Politics / Economics) */
function Triad({ surface, showMarks }) {
  const dark = surface.theme === "ink" || surface.theme === "flame";
  const ink = surface.theme === "flame" ? "var(--ink-900)" : (dark ? "var(--bone-50)" : "var(--ink-900)");
  const muted = surface.theme === "flame" ? "var(--ink-900)" : (dark ? "var(--bone-200)" : "var(--ink-700)");
  const items = [
    [CultureMark, "Culture", "Music, film, art, performance, and the life of the mind. The sound the renaissance made."],
    [PoliticsMark, "Politics", "Power, protest, citizenship. The New Negro in a new world, a century on."],
    [null, "Economics", "Work, ownership, and the ledger of a people. Who builds, who is paid, who is counted."],
  ];
  return (
    <section id="sections" data-theme={surface.theme || undefined} style={{ background: surface.bg, color: ink, padding: "clamp(4rem,8vw,6.5rem) 0", borderTop: dark ? "none" : "1px solid var(--bone-200)" }}>
      <div style={wrap}>
        <div className="rise"><Kicker kicker="Three Sections · Seven Pieces Each" headline="One issue, three fires." size="article" color={ink} style={{ "--color-rule": ink, "--color-fg-muted": muted }} /></div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "clamp(1.5rem,3vw,2.75rem)", marginTop: "2.75rem" }} className="triad-grid">
          {items.map(([Mark, name, copy], i) => (
            <div key={name} className="rise" style={{ borderTop: `3px solid ${ink}`, paddingTop: "1.5rem", "--rise-delay": `${i * 70}ms` }}>
              <div style={{ height: 96, marginBottom: "1.25rem", color: ink, opacity: showMarks ? 1 : 0, transition: "opacity 200ms var(--ease-out)" }}>{showMarks && Mark && <Mark s={96} />}</div>
              <h3 style={{ ...disp, fontWeight: 800, fontSize: "clamp(2rem,4.5vw,2.9rem)", lineHeight: 0.95, textTransform: "uppercase", color: ink, margin: "0 0 0.6rem" }}>{name}</h3>
              <p style={{ fontFamily: "var(--font-body)", fontSize: "1.02rem", lineHeight: 1.55, color: muted, margin: 0, maxWidth: "34ch" }}>{copy}</p>
            </div>
          ))}
        </div>
      </div>
      <style>{`@media (max-width: 720px){ .triad-grid{ grid-template-columns: 1fr !important; } }`}</style>
    </section>
  );
}

/* ============================================================ NO AI */
function NoAI() {
  return (
    <section id="no-ai" data-theme="ink" style={{ background: "var(--ink-900)", color: "var(--bone-50)", padding: "clamp(4.5rem,9vw,7.5rem) 0", textAlign: "center" }}>
      <div style={wrap}>
        <h2 className="rise" style={{ ...disp, fontWeight: 900, fontSize: "clamp(2.4rem,7vw,5.25rem)", lineHeight: 0.92, textTransform: "uppercase", margin: 0 }}>
          Absolutely no AI.<br /><span style={{ color: "var(--flame-400)" }}>Not in writing. Not in art.</span>
        </h2>
        <p className="rise" style={{ fontFamily: "var(--font-body)", fontSize: "var(--text-lg)", color: "var(--bone-200)", maxWidth: "58ch", margin: "1.85rem auto 0", lineHeight: 1.55, "--rise-delay": "70ms" }}>
          Every accepted piece goes through a human-made vetting process. FIRE!!! publishes work made by hands, voices, and minds — nothing else.
        </p>
        <div className="rise" style={{ marginTop: "2rem", "--rise-delay": "120ms" }}><Badge>Human-made, always</Badge></div>
      </div>
    </section>
  );
}

/* ============================================================ WHO */
function Who({ surface }) {
  const dark = surface.theme === "ink";
  const fg = dark ? "var(--bone-50)" : "var(--ink-900)";
  const rule = dark ? "var(--flame-600)" : "var(--bone-200)";
  const num = dark ? "var(--ochre-400)" : "var(--flame-600)";
  const muted = dark ? "var(--bone-200)" : "var(--ink-700)";
  const rows = [
    "African American artists, in the tradition of the original FIRE!! — descendants of people enslaved on this land.",
    "Ages 18 to 35.",
    "Unpublished voices first. If the world hasn't heard you yet, we want to be the ones who change that.",
    "One submission per person.",
  ];
  return (
    <section id="who" data-theme={dark ? "ink" : undefined} style={{ background: surface.bg, color: fg, padding: "clamp(4rem,8vw,7rem) 0" }}>
      <div style={wrap}>
        <div className="rise"><Kicker kicker="Eligibility" headline="Who we're looking for" size="article" color={fg} style={{ "--color-rule": fg, "--color-fg-muted": muted }} /></div>
        <ul style={{ listStyle: "none", margin: "2.5rem 0 0", padding: 0, maxWidth: "64rem" }}>
          {rows.map((t, i) => (
            <li key={i} className="rise" style={{ display: "grid", gridTemplateColumns: "auto 1fr", gap: "1.5rem", alignItems: "baseline", padding: "1.5rem 0", borderTop: `1px solid ${rule}`, borderBottom: i === rows.length - 1 ? `1px solid ${rule}` : "none", fontFamily: "var(--font-body)", fontSize: "clamp(1.2rem,2.1vw,1.5rem)", fontWeight: 500, "--rise-delay": `${i * 50}ms` }}>
              <span style={{ fontFamily: "var(--font-deco)", fontSize: "clamp(1.5rem,3vw,2.1rem)", color: num, lineHeight: 1 }}>{String(i + 1).padStart(2, "0")}</span>
              <span>{t}</span>
            </li>
          ))}
        </ul>
        <p className="rise" style={{ fontFamily: "var(--font-body)", fontStyle: "italic", color: muted, marginTop: "1.75rem", fontSize: "1.1rem", "--rise-delay": "220ms" }}>
          Each section also carries one donated piece from an established voice — for the cause.
        </p>
      </div>
    </section>
  );
}

/* ============================================================ THE WORK / PAY */
const PAY = [
  ["Short story", "$500"], ["Essay", "$600"], ["Photography / photo essay", "$500"],
  ["Art piece", "$500"], ["Conversation, roundtable, or interview", "$600"], ["Poem", "$200"],
];
const TERMS = [
  ["When you're paid", "25% once your proposal is accepted and agreements are signed. The remaining 75% when editing is complete."],
  ["Your rights", "Multimedia work: rights for television and film are split 50/50 between you and FIRE!!!."],
  ["Roundtables", "Group conversations pay $300 per participant."],
];
function TheWork() {
  return (
    <section id="the-work" style={{ background: "var(--bone-50)", padding: "clamp(4rem,8vw,7rem) 0" }}>
      <div style={wrap}>
        <div className="rise"><Kicker kicker="The Work" size="article" headline="What we're publishing. And what we pay." /></div>
        <p className="rise" style={{ fontFamily: "var(--font-body)", fontSize: "var(--text-base)", lineHeight: 1.62, color: "var(--ink-900)", maxWidth: "66ch", margin: "1.5rem 0 2.75rem", "--rise-delay": "60ms" }}>
          Seven pieces in each of three sections: <strong>Culture, Politics, Economics</strong>.<br />Framed by a foreword from Dr. Michelle Taylor, an introduction by YOU, an afterword by J. Brian Charles, and an epilogue from Blair Imani.
        </p>
        <div style={{ display: "grid", gridTemplateColumns: "minmax(0,1.15fr) minmax(0,0.85fr)", gap: "3rem 4.5rem", alignItems: "start" }} className="work-grid">
          <div className="rise" style={{ minWidth: 0 }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <caption style={{ textAlign: "left", marginBottom: "1rem", ...kickerStyle, fontSize: "0.8125rem", color: "var(--ink-700)" }}>Rates per accepted piece, per section</caption>
              <thead><tr>
                <th scope="col" style={{ textAlign: "left", padding: "0.85rem 0", borderBottom: "3px solid var(--ink-900)", ...kickerStyle, fontSize: "0.8125rem", color: "var(--ink-700)", letterSpacing: "0.1em" }}>Form</th>
                <th scope="col" style={{ textAlign: "right", padding: "0.85rem 0", borderBottom: "3px solid var(--ink-900)", ...kickerStyle, fontSize: "0.8125rem", color: "var(--ink-700)", letterSpacing: "0.1em" }}>Rate</th>
              </tr></thead>
              <tbody>{PAY.map(([form, amt]) => (
                <tr key={form}>
                  <th scope="row" style={{ textAlign: "left", padding: "0.95rem 1rem 0.95rem 0", borderBottom: "1px solid var(--bone-200)", fontFamily: "var(--font-body)", fontWeight: 400, fontSize: "1.05rem", color: "var(--ink-900)" }}>{form}</th>
                  <td style={{ textAlign: "right", padding: "0.95rem 0", borderBottom: "1px solid var(--bone-200)", fontFamily: "var(--font-deco)", fontSize: "1.4rem", color: "var(--flame-600)" }}>{amt}</td>
                </tr>
              ))}</tbody>
            </table>
          </div>
          <div className="rise" style={{ display: "grid", gap: "1.75rem", "--rise-delay": "80ms" }}>
            {TERMS.map(([h, b]) => (
              <div key={h}>
                <h3 style={{ ...kickerStyle, fontSize: "0.8125rem", letterSpacing: "0.12em", color: "var(--ink-900)", margin: "0 0 0.45rem" }}>{h}</h3>
                <p style={{ fontFamily: "var(--font-body)", fontSize: "1rem", lineHeight: 1.55, color: "var(--ink-700)", margin: 0, maxWidth: "40ch" }}>{b}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
      <style>{`@media (max-width: 760px){ .work-grid{ grid-template-columns: 1fr !important; } }`}</style>
    </section>
  );
}

/* ============================================================ SUBMIT CTA */
function SubmitCTA({ surface, onSubmit }) {
  const dark = surface.theme === "ink";
  const fg = dark ? "var(--bone-50)" : "var(--ink-900)";
  const muted = dark ? "var(--bone-200)" : "var(--ink-700)";
  return (
    <section id="submit-cta" data-theme={dark ? "ink" : undefined} style={{ background: surface.bg, color: fg, padding: "clamp(4rem,8vw,7rem) 0" }}>
      <div style={wrap}>
        <p className="rise" style={{ ...kickerStyle, fontSize: "0.8125rem", color: muted, margin: 0 }}>Proposals</p>
        <h2 className="rise" style={{ ...disp, fontWeight: 800, fontSize: "clamp(2.25rem,5vw,3.75rem)", lineHeight: 0.95, color: fg, margin: "0.5rem 0 2rem", "--rise-delay": "40ms" }}>How to submit</h2>
        <ol style={{ maxWidth: "62ch", paddingLeft: "1.25rem", margin: 0 }}>
          {["Choose your section — Culture, Politics, or Economics — and your form.",
            "Write a proposal: what you're making, why it belongs in FIRE!!!, and a sample of your voice or eye.",
            "Send it before the deadline. One submission per person."].map((t, i) => (
            <li key={i} className="rise" style={{ padding: "0.5rem 0", fontFamily: "var(--font-body)", fontSize: "1.18rem", color: fg, "--rise-delay": `${i * 50}ms` }}>{t}</li>
          ))}
        </ol>
        <p className="rise" style={{ ...disp, fontWeight: 800, textTransform: "uppercase", fontSize: "clamp(1.5rem,3.6vw,2.4rem)", color: dark ? "var(--ochre-400)" : "var(--flame-600)", margin: "2.5rem 0 1.5rem", "--rise-delay": "180ms" }}>Deadline · August 14, 2026</p>
        <div className="rise" style={{ "--rise-delay": "220ms" }}>
          <Button size="lg" onClick={onSubmit} style={dark ? { background: "var(--ink-900)", color: "var(--bone-50)" } : undefined}>Submit a Proposal</Button>
        </div>
      </div>
    </section>
  );
}

/* ============================================================ FOOTER */
function Footer() {
  return (
    <React.Fragment>
      <Sawtooth color="ink" />
      <footer data-theme="ink" style={{ background: "var(--ink-900)", color: "var(--bone-200)", padding: "3.25rem 0", borderTop: "6px solid var(--flame-500)" }}>
        <div style={{ ...wrap, display: "flex", flexWrap: "wrap", gap: "1.5rem 2.5rem", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div style={{ maxWidth: "30ch" }}>
            <span style={{ ...disp, fontWeight: 900, fontSize: "1.9rem", color: "var(--bone-50)", display: "block" }}>FIRE!!!</span>
            <p style={{ fontFamily: "var(--font-body)", fontStyle: "italic", color: "var(--bone-200)", margin: "0.4rem 0 0", fontSize: "1rem" }}>Devoted to Younger African American Artists.</p>
          </div>
          <div style={{ display: "grid", gap: "0.4rem" }}>
            <span style={{ ...kickerStyle, fontSize: "0.72rem", color: "var(--ink-300)" }}>Submit</span>
            <a href="mailto:submissions@fire-magazine.org" style={{ fontFamily: "var(--font-body)", color: "var(--bone-50)", fontSize: "1.02rem" }}>submissions@fire-magazine.org</a>
          </div>
          <div style={{ display: "grid", gap: "0.4rem" }}>
            <span style={{ ...kickerStyle, fontSize: "0.72rem", color: "var(--ink-300)" }}>Window</span>
            <span style={{ fontFamily: "var(--font-body)", color: "var(--bone-50)", fontSize: "1.02rem" }}>June 15 – August 14, 2026</span>
          </div>
        </div>
        <div style={{ ...wrap, marginTop: "2.5rem", paddingTop: "1.5rem", borderTop: "1px solid var(--ink-700)" }}>
          <p style={{ ...kickerStyle, fontSize: "0.72rem", color: "var(--ink-300)", margin: 0 }}>Culture + Politics + Economics · © 2026 FIRE!!! Magazine</p>
        </div>
      </footer>
    </React.Fragment>
  );
}

/* ============================================================ LANDING */
function Landing({ t, onSubmit }) {
  const s = surfaces(t.redIntensity);
  const readRef = React.useRef(null);
  const read = () => { const el = document.getElementById("the-call"); if (el) el.scrollIntoView(); };
  return (
    <main>
      <Hero scale={t.heroScale} onRead={read} onSubmit={onSubmit} />
      <Sawtooth color="ink" />
      <TheCall />
      <Sawtooth color={s.triad.theme ? "bone" : "flame"} flip />
      <Triad surface={s.triad} showMarks={t.showMarks} />
      <NoAI />
      <Who surface={s.who} />
      <Sawtooth color={s.who.theme === "ink" ? "bone" : "flame"} flip />
      <TheWork />
      <Sawtooth color="flame" />
      <SubmitCTA surface={s.submit} onSubmit={onSubmit} />
      <Footer />
    </main>
  );
}

/* ============================================================ SUBMIT SCREEN */
function SubmitScreen({ onBack, onDone }) {
  const [form, setForm] = React.useState({ name: "", email: "", section: "Culture", piece: "", proposal: "" });
  const [errors, setErrors] = React.useState({});
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const submit = (e) => {
    e.preventDefault();
    const er = {};
    if (!form.name.trim()) er.name = "Tell us your name.";
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email)) er.email = "Add a full email so we can reply to you.";
    if (!form.proposal.trim()) er.proposal = "Tell us what you want to make.";
    setErrors(er);
    if (Object.keys(er).length === 0) onDone(form);
  };
  return (
    <main>
      <section style={{ background: "var(--bone-50)", minHeight: "100vh", padding: "clamp(2.5rem,6vw,4.5rem) 0 5rem" }}>
        <div style={{ width: "min(42rem, 100% - 3rem)", marginInline: "auto" }}>
          <button onClick={onBack} style={{ background: "none", border: "none", cursor: "pointer", ...kickerStyle, fontSize: "0.8125rem", color: "var(--flame-600)", padding: 0, marginBottom: "1.5rem" }}>← Back to the call</button>
          <Kicker kicker="Call for Proposals" size="article" headline="Submit a proposal" standfirst="One submission per person. Tell us what you want to burn into the world." />
          <form onSubmit={submit} style={{ marginTop: "2.5rem" }} noValidate>
            <Field label="Your name" value={form.name} onChange={set("name")} error={errors.name} required />
            <Field label="Email" type="email" value={form.email} onChange={set("email")} error={errors.email} required />
            <div style={{ marginBottom: "1.5rem" }}>
              <span style={{ display: "block", ...kickerStyle, fontWeight: 600, fontSize: "var(--text-sm)", color: "var(--color-fg)", marginBottom: "0.6rem" }}>Section</span>
              <div style={{ display: "flex", gap: "0.75rem", flexWrap: "wrap" }}>
                {["Culture", "Politics", "Economics"].map((sec) => (
                  <button type="button" key={sec} onClick={() => setForm((f) => ({ ...f, section: sec }))}
                    style={{ ...disp, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em", fontSize: "0.85rem", padding: "0.7rem 1.25rem", cursor: "pointer", borderRadius: 0, border: "3px solid var(--ink-900)", background: form.section === sec ? "var(--ink-900)" : "transparent", color: form.section === sec ? "var(--bone-50)" : "var(--ink-900)", transition: "background-color 180ms var(--ease-out), color 180ms var(--ease-out)" }}>{sec}</button>
                ))}
              </div>
            </div>
            <Field label="Form" value={form.piece} onChange={set("piece")} placeholder="Short story, poem, essay, photo essay…" hint="What form will your piece take?" />
            <Field label="Your proposal" textarea value={form.proposal} onChange={set("proposal")} error={errors.proposal} placeholder="What you're making, why it belongs in FIRE!!!, and a sample of your voice or eye." required />
            <div style={{ display: "flex", gap: "1rem", marginTop: "0.5rem", alignItems: "center", flexWrap: "wrap" }}>
              <Button type="submit">Send it in</Button>
              <span style={{ fontFamily: "var(--font-body)", fontStyle: "italic", fontSize: "0.95rem", color: "var(--ink-700)" }}>Deadline · August 14, 2026</span>
            </div>
          </form>
        </div>
      </section>
      <Footer />
    </main>
  );
}

/* ============================================================ CONFIRMATION */
function Confirmation({ form, onHome }) {
  const first = form && form.name ? form.name.trim().split(" ")[0] : "";
  return (
    <main>
      <section data-theme="flame" style={{ background: "var(--flame-500)", color: "var(--ink-900)", minHeight: "100vh", display: "flex", alignItems: "center", padding: "4rem 0" }}>
        <div style={{ width: "min(46rem, 100% - 3rem)", marginInline: "auto" }}>
          <p style={{ ...kickerStyle, fontSize: "0.85rem", margin: 0 }}>Proposal received</p>
          <h1 style={{ ...disp, fontWeight: 900, fontSize: "clamp(3.25rem,11vw,6.75rem)", lineHeight: 0.88, textTransform: "uppercase", margin: "0.5rem 0 0", borderTop: "6px solid var(--ink-900)", paddingTop: "1.25rem" }}>The match<br />is struck.</h1>
          <p style={{ fontFamily: "var(--font-body)", fontSize: "1.3rem", lineHeight: 1.5, maxWidth: "46ch", marginTop: "1.75rem" }}>
            Thank you{first ? `, ${first}` : ""}. Your {form ? form.section : ""} proposal is in. We read every submission by hand — no AI, not even here. If it moves us, you'll hear from us before the editing season opens.
          </p>
          <div style={{ marginTop: "2.5rem", display: "flex", gap: "1rem", flexWrap: "wrap" }}>
            <Button variant="secondary" size="lg" onClick={onHome}>Back to the call</Button>
          </div>
        </div>
      </section>
    </main>
  );
}

/* ============================================================ APP */
function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [view, setView] = React.useState("landing");
  const [form, setForm] = React.useState(null);

  React.useEffect(() => { window.scrollTo(0, 0); }, [view]);
  React.useEffect(() => {
    document.documentElement.style.setProperty("--grain-opacity", t.grain ? "0.04" : "0");
  }, [t.grain]);

  return (
    <div style={{ fontFamily: "var(--font-body)" }}>
      <Nav view={view} onSubmit={() => setView("submit")} onHome={() => setView("landing")} />
      {view === "landing" && <Landing t={t} onSubmit={() => setView("submit")} />}
      {view === "submit" && <SubmitScreen onBack={() => setView("landing")} onDone={(f) => { setForm(f); setView("confirm"); }} />}
      {view === "confirm" && <Confirmation form={form} onHome={() => setView("landing")} />}

      <TweaksPanel>
        <TweakSection label="Color" />
        <TweakRadio label="Red intensity" value={t.redIntensity} options={["restrained", "committed", "drenched"]} onChange={(v) => setTweak("redIntensity", v)} />
        <TweakSection label="Hero" />
        <TweakSlider label="Masthead scale" value={t.heroScale} min={0.8} max={1.25} step={0.05} onChange={(v) => setTweak("heroScale", v)} />
        <TweakSection label="Ornament" />
        <TweakToggle label="Section marks" value={t.showMarks} onChange={(v) => setTweak("showMarks", v)} />
        <TweakToggle label="Letterpress grain" value={t.grain} onChange={(v) => setTweak("grain", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
