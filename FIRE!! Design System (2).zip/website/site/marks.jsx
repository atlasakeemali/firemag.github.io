/* ============================================================
   FIRE!!! — Section marks. Pure hard-edged geometry only
   (rings, rays, the ziggurat step). NOT figurative illustration
   and NOT the AI reference sheets. Phase-2-ready section identity
   built from the brand's own ornament vocabulary.
   Color follows `currentColor`; size via the `s` prop.
   ============================================================ */

function CultureMark({ s = 96, stroke = 3, style }) {
  // Concentric rings + radiating rays — sound, the jazz cone, the earring.
  return (
    <svg width={s} height={s} viewBox="0 0 120 120" fill="none" aria-hidden="true"
      style={{ display: "block", color: "currentColor", ...style }}>
      <g stroke="currentColor" strokeWidth={stroke}>
        <circle cx="46" cy="60" r="10" fill="currentColor" stroke="none" />
        <circle cx="46" cy="60" r="20" />
        <circle cx="46" cy="60" r="30" />
        <circle cx="46" cy="60" r="40" />
      </g>
      <g stroke="currentColor" strokeWidth={stroke} strokeLinecap="square">
        <path d="M96 28 L112 22" /><path d="M100 44 L118 40" />
        <path d="M102 60 L120 60" /><path d="M100 76 L118 80" />
        <path d="M96 92 L112 98" />
      </g>
    </svg>
  );
}

function PoliticsMark({ s = 96, stroke = 3, style }) {
  // The rise — an ascending ziggurat stair with an upward chevron.
  return (
    <svg width={s} height={s} viewBox="0 0 120 120" fill="none" aria-hidden="true"
      style={{ display: "block", color: "currentColor", ...style }}>
      <g fill="currentColor">
        <rect x="8" y="84" width="28" height="28" />
        <rect x="36" y="64" width="28" height="48" />
        <rect x="64" y="44" width="28" height="68" />
      </g>
      <path d="M70 38 L92 16 L114 38" stroke="currentColor" strokeWidth={stroke + 1}
        strokeLinecap="square" strokeLinejoin="miter" fill="none" />
    </svg>
  );
}

function EconomicsMark({ s = 96, stroke = 3, style }) {
  // Balance — a hard-edged beam over two planes, the ledger stack at the foot.
  return (
    <svg width={s} height={s} viewBox="0 0 120 120" fill="none" aria-hidden="true"
      style={{ display: "block", color: "currentColor", ...style }}>
      <g stroke="currentColor" strokeWidth={stroke} strokeLinecap="square" fill="none">
        <path d="M60 18 L60 44" />
        <path d="M26 30 L94 30" />
        <path d="M26 30 L14 52 L38 52 Z" />
        <path d="M94 30 L82 52 L106 52 Z" />
      </g>
      <g fill="currentColor">
        <rect x="40" y="78" width="40" height="8" />
        <rect x="34" y="90" width="52" height="8" />
        <rect x="46" y="102" width="28" height="8" />
        <circle cx="60" cy="44" r="5" />
      </g>
    </svg>
  );
}

window.FireMarks = { CultureMark, PoliticsMark, EconomicsMark };
